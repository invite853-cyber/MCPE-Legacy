# MCPE Legacy Launcher

A native Android starter project for organizing locally held Minecraft Pocket Edition APKs and browsing Internet Archive software records.

## Features
- Search Internet Archive's Advanced Search API.
- Inspect an item's metadata and open its archive record.
- Show APK files found in an archive item. Downloads are restricted to records that declare a reusable licence marker; verify the exact rights on the item page.
- Import APK files using Android's system file picker.
- Keep imported APK files in app-private storage and hand installation to Android's package installer.
- Open the standard Minecraft PE package (`com.mojang.minecraftpe`) when installed.

## Build without a computer (GitHub Actions)
This project includes `.github/workflows/build-apk.yml` for a cloud build.

1. Create a GitHub account and a **new public or private repository** from your phone.
2. Upload the *contents* of this project folder to the repository (including the hidden `.github` folder). Do not upload only the ZIP as a single file.
3. Open the repository's **Actions** tab, select **Build MCPE Legacy APK**, then choose **Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open that workflow run, scroll to **Artifacts**, and download `MCPE-Legacy-debug-APK`.
6. Extract the downloaded artifact ZIP and tap `app-debug.apk` to install. Android may ask you to allow installs from the browser or file manager you used.

The debug APK is signed with a temporary debug key by the build system. It is suitable for personal testing, not Play Store publishing. Keep the GitHub repository private if you do not want the source project public.

## Build locally
Use Android Studio with JDK 17, Android SDK Platform 35, and Gradle 8.9, then run `gradle assembleDebug` from this folder.

## Notes
- Internet Archive search and metadata endpoints are public read endpoints. Archive metadata is supplied by uploaders and is not a legal determination; check rights and licence terms on the item page.
- Android may refuse very old APKs because of signing, SDK, ABI, or OS compatibility. The app does not bypass those protections.
- This is a launcher/library, not an emulator. It cannot make incompatible old Android builds run on a newer device.
