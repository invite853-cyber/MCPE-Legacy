package com.legacy.mcpe;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.*;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private LinearLayout root, results, library;
    private EditText search;
    private TextView status;
    private static final int PICK_APK = 41;
    private int green = 0xFF79C957, panel = 0xFF1B251B, muted = 0xFFB2BDAF;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF111711);
        getWindow().setNavigationBarColor(0xFF111711);
        buildUi(); refreshLibrary();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28)); root.setBackgroundColor(0xFF111711);
        scroll.addView(root); setContentView(scroll);

        TextView logo = text("▦  MCPE LEGACY", 25, 0xFFFFFFFF, true); root.addView(logo);
        TextView subtitle = text("A little library of Pocket Edition history", 13, muted, false); root.addView(subtitle);
        space(root, 18);
        TextView archiveTitle = text("ARCHIVE BROWSER", 13, green, true); root.addView(archiveTitle);
        search = new EditText(this); search.setSingleLine(true); search.setTextColor(-1);
        search.setHintTextColor(muted); search.setHint("Search Internet Archive…");
        search.setPadding(dp(12), 0, dp(12), 0); search.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(50)));
        Button find = button("SEARCH ARCHIVE"); root.addView(find); find.setOnClickListener(v -> searchArchive(search.getText().toString().trim()));
        TextView rights = text("Archive results are reference listings. Downloads are enabled only when an item clearly declares a reusable licence. Check the item page and its rights before using files.", 12, muted, false);
        rights.setPadding(0, dp(8), 0, dp(8)); root.addView(rights);
        status = text("Search for a release or archive item.", 13, muted, false); root.addView(status);
        results = new LinearLayout(this); results.setOrientation(LinearLayout.VERTICAL); root.addView(results);

        space(root, 22);
        root.addView(text("MY APK LIBRARY", 13, green, true));
        TextView localDesc = text("Import APK files you already have. Android will handle installation and any compatibility warnings.", 12, muted, false);
        root.addView(localDesc);
        Button launchBtn = button("▶  OPEN MINECRAFT PE"); root.addView(launchBtn);
        launchBtn.setOnClickListener(v -> { Intent launch=getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe"); if(launch!=null) startActivity(launch); else status.setText("Minecraft PE is not installed (or uses a different package ID)."); });
        Button importBtn = button("＋  IMPORT APK"); root.addView(importBtn);
        importBtn.setOnClickListener(v -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("application/vnd.android.package-archive"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, PICK_APK); });
        library = new LinearLayout(this); library.setOrientation(LinearLayout.VERTICAL); root.addView(library);
        space(root, 20);
        TextView footer = text("MCPE LEGACY  •  Archive metadata via Internet Archive", 11, muted, false); root.addView(footer);
    }

    private void searchArchive(String q) {
        if (q.isEmpty()) q = "Minecraft Pocket Edition";
        final String term = q;
        status.setText("Searching…"); results.removeAllViews();
        worker.execute(() -> {
            try {
                String query = "mediatype:software AND (" + term + ")";
                String url = "https://archive.org/advancedsearch.php?q=" + URLEncoder.encode(query, "UTF-8") + "&fl[]=identifier&fl[]=title&fl[]=date&fl[]=description&rows=25&page=1&output=json";
                JSONObject data = new JSONObject(get(url)); JSONArray docs = data.getJSONObject("response").getJSONArray("docs");
                runOnUiThread(() -> {
                    status.setText(docs.length() + " archive item(s) found. Open an item to inspect its record.");
                    for (int i=0; i<docs.length(); i++) {
                        JSONObject d = docs.optJSONObject(i); if (d == null) continue;
                        String id = d.optString("identifier", ""), title = d.optString("title", id), date = d.optString("date", "Date unknown");
                        addArchiveCard(title, date, id);
                    }
                    if (docs.length()==0) status.setText("No results. Try a broader search such as Minecraft.");
                });
            } catch (Exception e) { runOnUiThread(() -> status.setText("Search failed: " + e.getMessage())); }
        });
    }

    private void addArchiveCard(String title, String date, String id) {
        LinearLayout card = card();
        card.addView(text(title, 16, -1, true)); card.addView(text(date + "  •  " + id, 12, muted, false));
        Button open = button("VIEW ARCHIVE RECORD"); card.addView(open);
        open.setOnClickListener(v -> inspectItem(id)); results.addView(card);
    }

    private void inspectItem(String id) {
        status.setText("Checking item rights…");
        worker.execute(() -> {
            try {
                JSONObject record = new JSONObject(get("https://archive.org/metadata/" + URLEncoder.encode(id, "UTF-8")));
                JSONObject meta = record.optJSONObject("metadata"); if (meta == null) meta = new JSONObject();
                String title = meta.optString("title", id);
                String rights = (meta.optString("licenseurl", "") + " " + meta.optString("rights", "") + " " + meta.optString("license", "")).toLowerCase(Locale.ROOT);
                boolean reusable = rights.contains("creativecommons.org/licenses/") || rights.contains("creativecommons.org/publicdomain/") || rights.contains("public domain") || rights.contains("cc0");
                JSONArray files = record.optJSONArray("files"); ArrayList<String> apks = new ArrayList<>();
                if (files != null) for (int i=0; i<files.length(); i++) { String name=files.optJSONObject(i)==null?"":files.optJSONObject(i).optString("name", ""); if (name.toLowerCase(Locale.ROOT).endsWith(".apk")) apks.add(name); }
                final boolean allowed = reusable; final String t = title; final ArrayList<String> names=apks;
                runOnUiThread(() -> {
                    status.setText("Record: " + t + " | APK files: " + names.size() + " | Reusable licence detected: " + (allowed ? "yes" : "no"));
                    LinearLayout card=card(); card.addView(text(t,16,-1,true));
                    card.addView(text(allowed ? "A Creative Commons / public-domain style licence was found. Verify the exact terms on the item page." : "No clear reusable licence was found. Download is disabled here; you can still review the archive record.",12,muted,false));
                    Button page=button("OPEN ITEM PAGE"); card.addView(page); page.setOnClickListener(v -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://archive.org/details/"+Uri.encode(id)))));
                    if (allowed) for (String name:names) { Button dl=button("DOWNLOAD  " + name); card.addView(dl); dl.setOnClickListener(v -> downloadArchiveFile(id,name)); }
                    results.addView(card,0);
                });
            } catch(Exception e) { runOnUiThread(() -> status.setText("Could not read item metadata: "+e.getMessage())); }
        });
    }

    private void downloadArchiveFile(String id, String name) {
        try {
            String url="https://archive.org/download/"+Uri.encode(id)+"/"+Uri.encode(name).replace("%2F","/");
            DownloadManager.Request req=new DownloadManager.Request(Uri.parse(url));
            req.setTitle(name); req.setDescription("Downloading a file with a declared reusable licence");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"MCPE-Legacy/"+name);
            ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);
            status.setText("Download queued. Check the Android download notification.");
        } catch(Exception e) { status.setText("Could not start download: "+e.getMessage()); }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_APK && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            Uri uri=data.getData(); try { getContentResolver().takePersistableUriPermission(uri, data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            worker.execute(() -> copyApk(uri));
        }
    }

    private void copyApk(Uri uri) {
        try {
            String name="imported-"+System.currentTimeMillis()+".apk";
            try(android.database.Cursor c=getContentResolver().query(uri,null,null,null,null)) { if(c!=null && c.moveToFirst()){int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(ix>=0){String n=c.getString(ix); if(n!=null && n.toLowerCase(Locale.ROOT).endsWith(".apk")) name=n.replaceAll("[^a-zA-Z0-9._-]","_");}} }
            File dir=new File(getFilesDir(),"apks"); if(!dir.exists()) dir.mkdirs(); File dest=new File(dir,name);
            try(InputStream in=getContentResolver().openInputStream(uri); OutputStream out=new FileOutputStream(dest)){byte[] b=new byte[8192]; int n; while((n=in.read(b))>0) out.write(b,0,n);}
            runOnUiThread(() -> { status.setText("Imported: "+name); refreshLibrary(); });
        } catch(Exception e){runOnUiThread(()->status.setText("Import failed: "+e.getMessage()));}
    }

    private void refreshLibrary() {
        if(library==null)return; library.removeAllViews(); File dir=new File(getFilesDir(),"apks"); File[] files=dir.listFiles((d,n)->n.toLowerCase(Locale.ROOT).endsWith(".apk"));
        if(files==null || files.length==0){library.addView(text("No APKs imported yet.",13,muted,false));return;}
        Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        for(File f:files){ LinearLayout c=card(); c.addView(text(f.getName(),15,-1,true)); c.addView(text(android.text.format.Formatter.formatFileSize(this,f.length()),12,muted,false));
            Button install=button("INSTALL APK"); c.addView(install); install.setOnClickListener(v->installApk(f)); library.addView(c); }
    }

    private void installApk(File file) {
        if(Build.VERSION.SDK_INT>=26 && !getPackageManager().canRequestPackageInstalls()) {
            Intent settings=new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())); startActivity(settings); return;
        }
        try { Uri uri=FileProvider.getUriForFile(this,getPackageName()+".provider",file); Intent i=new Intent(Intent.ACTION_INSTALL_PACKAGE); i.setData(uri); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(i); }
        catch(Exception e){ status.setText("Installer could not open this APK: "+e.getMessage()); }
    }

    private String get(String address) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection(); c.setConnectTimeout(12000); c.setReadTimeout(15000); c.setRequestProperty("User-Agent","MCPE-Legacy-Android/1.0");
        try(InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");} finally {c.disconnect();}
    }
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(14),dp(12),dp(14),dp(12));c.setBackgroundColor(panel);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(9);c.setLayoutParams(p);return c;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(0xFF10200D);b.setTextSize(12);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));return b;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
    private void space(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdownNow();}
}
